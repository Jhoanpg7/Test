package com.directores.demo;


import com.directores.demo.controller.DirectorController;
import com.directores.demo.service.DirectorService;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Arrays;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(DirectorController.class)
public class DirectorControllerTest {
	
	@Autowired
    private MockMvc mockMvc;

    @MockBean
    private DirectorService directorService;

    @Test
    public void testGetDirectors() throws Exception {
        Mockito.when(directorService.getDirectors(2)).thenReturn(Arrays.asList("Director1", "Director2"));

        mockMvc.perform(get("/api/directors?threshold=2"))
                .andExpect(status().isOk())
                .andExpect(content().json("[\"Director1\",\"Director2\"]"));
    }

}
