package com.directores.demo;


import com.directores.demo.impl.DirectorServiceImpl;
import com.directores.demo.model.Movie;
import com.directores.demo.repository.Repository;
import com.directores.demo.service.DirectorService;
import com.directores.demo.exception.MovieNotFoundException;
import com.directores.demo.model.MovieResponse;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.*;

class DemoApplicationTests {

		@Mock
	    private RestTemplate restTemplate;

	    @InjectMocks
	    private DirectorServiceImpl directorService;

	    @BeforeEach
	    public void setup() {
	        MockitoAnnotations.openMocks(this);
	    }

	    @Test
	    public void testCountMoviesByDirector() throws Exception {
	        List<Movie> movies = Arrays.asList(
	                new Movie("Director1", "Movie1"),
	                new Movie("Director1", "Movie2"),
	                new Movie("Director2", "Movie3")
	        );

	        MovieResponse movieResponse = new MovieResponse();
	        movieResponse.setData(movies);

	        when(restTemplate.getForObject(anyString(), eq(MovieResponse.class))).thenReturn(movieResponse);

	        Map<String, Long> result = directorService.countMoviesByDirector();
	        assertEquals(2, result.get("Director1"));
	        assertEquals(1, result.get("Director2"));
	    }

	    @Test
	    public void testGetDirectors() throws Exception {
	        List<Movie> movies = Arrays.asList(
	                new Movie("Director1", "Movie1"),
	                new Movie("Director2", "Movie2"),
	                new Movie("Director3", "Movie3"),
	                new Movie("Director4", "Movie4"),
	                new Movie("Director5", "Movie5")
	        );

	        MovieResponse movieResponse = new MovieResponse();
	        movieResponse.setData(movies);

	        when(restTemplate.getForObject(anyString(), eq(MovieResponse.class))).thenReturn(movieResponse);

	        List<String> result = directorService.getDirectors(2);
	        assertEquals(Arrays.asList("Director1", "Director2"), result);
	    }

	    @Test
	    public void testGetDirectorsWithDifferentThreshold() throws Exception {
	        List<Movie> movies = Arrays.asList(
	                new Movie("Director1", "Movie1"),
	                new Movie("Director2", "Movie2"),
	                new Movie("Director3", "Movie3"),
	                new Movie("Director4", "Movie4"),
	                new Movie("Director5", "Movie5")
	        );

	        MovieResponse movieResponse = new MovieResponse();
	        movieResponse.setData(movies);

	        when(restTemplate.getForObject(anyString(), eq(MovieResponse.class))).thenReturn(movieResponse);

	        List<String> result = directorService.getDirectors(1);
	        assertEquals(Arrays.asList("Director1", "Director2", "Director3", "Director4", "Director5"), result);
	    }

	    @Test
	    public void testCountMoviesByDirectorWithError() {
	        MovieResponse movieResponse = new MovieResponse();
	        movieResponse.setData(Arrays.asList());
	        
	        when(restTemplate.getForObject(anyString(), eq(MovieResponse.class))).thenReturn(movieResponse);

	        Exception exception = assertThrows(MovieNotFoundException.class, () -> {
	            directorService.countMoviesByDirector();
	        });

	        assertEquals("No movies found", exception.getMessage());
	    }
	    
	    @Test
	    public void testCountMoviesByDirectorWithError1() {
	        when(restTemplate.getForObject(anyString(), eq(MovieResponse.class))).thenThrow(new HttpClientErrorException(HttpStatus.NOT_FOUND));

	        assertThrows(MovieNotFoundException.class, () -> directorService.countMoviesByDirector());
	    }

	    @Test
	    public void testGetDirectorsWithError() {
	        when(restTemplate.getForObject(anyString(), eq(MovieResponse.class))).thenThrow(new HttpClientErrorException(HttpStatus.NOT_FOUND));

	        assertThrows(MovieNotFoundException.class, () -> directorService.getDirectors(1));
	    }
}
