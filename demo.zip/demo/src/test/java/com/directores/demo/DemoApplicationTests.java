package com.directores.demo;


import com.directores.demo.impl.DirectorServiceImpl;
import com.directores.demo.model.Movie;
import com.directores.demo.repository.Repository;
import com.directores.demo.service.DirectorService;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;
import org.junit.jupiter.api.Test;



class DemoApplicationTests {

	@Mock
    private Repository movieRepository;
	@InjectMocks
    private DirectorServiceImpl directorService;

    public DemoApplicationTests() {
        MockitoAnnotations.openMocks(this);
    }
    
    @BeforeEach
    public void setup() {
        MockitoAnnotations.openMocks(this);
    }
	
	  @Test
	    public void testCountMoviesByDirector() {
	        Repository movieRepository = Mockito.mock(Repository.class);
	        DirectorService directorService = new DirectorServiceImpl();

	        List<Movie> movies = Arrays.asList(
	                new Movie("Director1", "Movie1"),
	                new Movie("Director1", "Movie2"),
	                new Movie("Director2", "Movie3")
	        );

	        when(movieRepository.getMovies()).thenReturn(movies);

	        Map<String, Long> result = directorService.countMoviesByDirector();
	        assertEquals(2, result.get("Director1"));
	        assertEquals(1, result.get("Director2"));
	    }

	    @Test
	    public void testGetDirectors() {
	        Repository movieRepository = Mockito.mock(Repository.class);
	        DirectorService directorService = new DirectorServiceImpl();

	        List<Movie> movies = Arrays.asList(
	                new Movie("Director1", "Movie1"),
	                new Movie("Director2", "Movie2"),
	                new Movie("Director3", "Movie3"),
	                new Movie("Director4", "Movie4"),
	                new Movie("Director5", "Movie5")
	        );

	        when(movieRepository.getMovies()).thenReturn(movies);

	        List<String> result = directorService.getDirectors(2);
	        assertEquals(Arrays.asList("Director1", "Director2"), result);
	    }
}
