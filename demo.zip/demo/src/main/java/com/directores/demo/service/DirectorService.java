package com.directores.demo.service;
import java.util.List;
import java.util.Map;

public interface DirectorService {

	
	   Map<String, Long> countMoviesByDirector() throws Exception;
	   List<String> getDirectors(int threshold) throws Exception;
	  
	
}
