package com.directores.demo.impl;
import com.directores.demo.model.Movie;
import com.directores.demo.impl.MovieRepository;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Repository;
import org.springframework.web.client.RestTemplate;

import java.util.Arrays;
import java.util.List;


@Repository
public abstract class MovieRepository implements Repository {
	
	
	@Value("${https://eroninternational-movies.wiremockapi.cloud/}")
    private String apiUrl;

    private final RestTemplate restTemplate;

    public MovieRepository(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    public List<MovieRepository> getMovies() {
        MovieRepository[] movies = restTemplate.getForObject(apiUrl + "/movies", MovieRepository[].class);
        return Arrays.asList(movies);
    }

}
