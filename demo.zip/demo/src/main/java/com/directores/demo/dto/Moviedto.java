package com.directores.demo.dto;

import lombok.Data;

@Data
public class Moviedto {
    private String director;
    private String title;
	public String getDirector() {
		return director;
	}
	public void setDirector(String director) {
		this.director = director;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
}