package com.directores.demo.impl;

import com.directores.demo.exception.MovieNotFoundException;
import com.directores.demo.model.Movie;
import com.directores.demo.repository.Repository;
import com.directores.demo.service.DirectorService;
import com.directores.demo.model.MovieResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestTemplate;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class DirectorServiceImpl implements DirectorService {
	
	private final Repository movieRepository;
    private final RestTemplate restTemplate;
    private final String apiUrl = "https://directa24-movies.wiremockapi.cloud/api/movies/search";

    @Autowired
    public DirectorServiceImpl(Repository movieRepository, RestTemplate restTemplate) {
        this.movieRepository = movieRepository;
        this.restTemplate = restTemplate;
    }

    @Override
    public Map<String, Long> countMoviesByDirector() throws Exception {
        List<Movie> movies = fetchMoviesFromApi();
        if (movies.isEmpty()) {
            throw new Exception("No movies found");
        }
        return movies.stream().collect(Collectors.groupingBy(Movie::getDirector, Collectors.counting()));
    }

    @Override
    public List<String> getDirectors(int threshold) {
        MovieResponse response = restTemplate.getForObject(apiUrl, MovieResponse.class);

        if (response == null || response.getData().isEmpty()) {
            throw new MovieNotFoundException("No movies found");
        }

        return response.getData().stream()
                .collect(Collectors.groupingBy(Movie::getDirector, Collectors.counting()))
                .entrySet().stream()
                .filter(entry -> entry.getValue() >= threshold)
                .map(Map.Entry::getKey)
                .sorted()
                .collect(Collectors.toList());
    }

    private List<Movie> fetchMoviesFromApi() throws Exception {
        try {
            Movie[] movies = restTemplate.getForObject(apiUrl, Movie[].class);
            return List.of(movies != null ? movies : new Movie[0]);
        } catch (HttpClientErrorException | HttpServerErrorException e) {
            throw new Exception("Failed to fetch movies from API: " + e.getMessage());
        } catch (Exception e) {
            throw new Exception("An unexpected error occurred while fetching movies: " + e.getMessage());
        }
    }
}