package com.directores.demo.impl;

import com.directores.demo.model.Movie;
import com.directores.demo.repository.Repository;
import com.directores.demo.service.DirectorService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class DirectorServiceImpl implements DirectorService {
	
	 private  Repository movieRepository;
	 
	   @Autowired
	    public void DirectorService(Repository movieRepository) {
	        this.movieRepository = movieRepository;
	    }
	   	
	   @Override
	    public Map<String, Long> countMoviesByDirector() {
	        List<Movie> movies = movieRepository.getMovies();
	        return movies.stream()
	                .collect(Collectors.groupingBy(Movie::getDirector, Collectors.counting()));
	    }
	   
	   @Override
	    public List<String> getDirectors(int threshold) {
	        return movieRepository.getMovies().stream()
	                .collect(Collectors.groupingBy(Movie::getDirector, Collectors.counting()))
	                .entrySet().stream()
	                .filter(entry -> entry.getValue() > threshold)
	                .map(Map.Entry::getKey)
	                .sorted()
	                .collect(Collectors.toList());
	    }
	    }
