package com.directores.demo.repository;

import com.directores.demo.model.Director;
import com.directores.demo.model.Movie;
import java.util.List;

public interface Repository {
    List<Movie> getMovies();
    List<Director> getDirector();
    
}