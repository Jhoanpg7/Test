package com.directores.demo.model;

public class Director {
	private String director;

	public Director(String director) {
		super();
		this.director = director;
	}

	public String getDirector() {
		return director;
	}

	public void setDirector(String director) {
		this.director = director;
	}
	

}
