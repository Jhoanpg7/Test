package com.directores.demo.controller;


import com.directores.demo.service.DirectorService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController

public class DirectorController {

	private final DirectorService directorService;

    public DirectorController(DirectorService directorService) {
        this.directorService = directorService;
    }

    @GetMapping("/api/directors")
    public List<String> getDirectors(@RequestParam int threshold) throws Exception {
        return directorService.getDirectors(threshold);
    }
	
	
}
