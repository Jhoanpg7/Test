package com.directores.demo.exception;

public class CustomExceptions extends RuntimeException{

	    public CustomExceptions(String message) {
	        super(message);
	    }
}
