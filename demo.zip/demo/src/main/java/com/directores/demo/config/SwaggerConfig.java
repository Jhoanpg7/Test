package com.directores.demo.config;

public class SwaggerConfig {

}
