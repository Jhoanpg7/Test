package com.directores.demo.model;
import java.io.Serializable;

import lombok.Data;

@Data
public class Movie {
	
		private String director;
	    private String title;
	


		public Movie(String director, String title) {
			super();
			this.director = director;
			this.title = title;
		}

		  public String getDirector() {
		        return director;
		    }

		    public String getTitle() {
		        return title;
		    }

}


