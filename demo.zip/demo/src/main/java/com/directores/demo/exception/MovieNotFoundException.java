package com.directores.demo.exception;

public class MovieNotFoundException extends RuntimeException {
	
    public MovieNotFoundException(String message) {
        super(message);
    }


}
